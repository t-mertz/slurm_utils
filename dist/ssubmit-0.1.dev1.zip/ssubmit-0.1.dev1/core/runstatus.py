#import ssubmit
import core
import sys

if __name__ == "__main__":
    core.main('status', *sys.argv)