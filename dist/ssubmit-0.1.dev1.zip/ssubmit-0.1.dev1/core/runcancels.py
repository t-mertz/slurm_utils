import scancel
import sys

if __name__ == "__main__":
    scancel.main(sys.argv)
    