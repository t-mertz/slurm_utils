#import ssubmit
import core
import sys

if __name__ == "__main__":
#    ssubmit.main('submit', *sys.argv)
    core.main('submit', *sys.argv)