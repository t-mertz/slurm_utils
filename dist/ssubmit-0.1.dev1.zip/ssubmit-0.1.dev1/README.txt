Install by running

>> python setup.py install --user